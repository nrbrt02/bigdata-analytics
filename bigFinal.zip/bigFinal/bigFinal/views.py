from django.shortcuts import render
import joblib
from django.contrib import messages
def home(request):
        if request.method == 'POST':
                Pclass = int(request.POST.get('Pclass', False))
                Sex = int(request.POST.get('Sex', False))
                SibSp = int(request.POST.get('SibSp', False))
                Parch = int(request.POST.get('Parch', False))
                Age = int(request.POST.get('Age', False))
                Fare = int(request.POST.get('Fare', False))
                Embarked_C = int(request.POST.get('Embarked_C', False))
                Embarked_Q = int(request.POST.get('Embarked_Q', False))
                Embarked_S = int(request.POST.get('Embarked_S', False))
                data = [Pclass, Sex, SibSp, Age, Parch, Fare, Embarked_C, Embarked_Q, Embarked_S]
                # print(data)
                load_joblib = joblib.load("pesistance_model.pkl")
                answer = load_joblib.predict([data])
                # print(answer)
                if answer[0] == 1:
                        messages.success(request, "survived")
                else:
                         messages.success(request, "no-survived")
        return render(request, 'index.html')

# def prediction(request):


        # return render(request, 'prediction.html', {'answer': answer[0]})